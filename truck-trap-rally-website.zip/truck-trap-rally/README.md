# Truck Trap Rally website

Everything the game needs is in `index.html`. There's no build step and no server to run. Any free static host works.

## Put it online (pick one)

### Option A: Netlify Drop (fastest, about 2 minutes)
1. Go to https://app.netlify.com/drop and make a free account.
2. Drag this whole folder onto the page.
3. You get a link like `https://something-random.netlify.app`. In **Site settings → Change site name** you can make it `truck-trap-rally.netlify.app` if the name is free.

### Option B: GitHub Pages (free, good if you'll keep updating it)
1. Make a free GitHub account and a new **public** repository, for example `truck-trap-rally`.
2. Upload `index.html` (use **Add file → Upload files**).
3. Open **Settings → Pages**, set **Source** to "Deploy from a branch", pick `main` and `/ (root)`, and save.
4. After a minute the game is at `https://YOUR-NAME.github.io/truck-trap-rally/`.

### Option C: itch.io (game site with a community)
1. Make a free account on itch.io and create a new project, with **Kind of project** set to HTML.
2. Zip `index.html` and upload the zip, then tick "This file will be played in the browser".
3. Set the viewport to something like 1280 × 720 and turn on the fullscreen button.

## A custom name like truck-trap-rally.com
After it's on Netlify or GitHub Pages, buy a domain (about $10–15 a year) and follow the host's "custom domain" guide.

## How online multiplayer works here
- Players connect straight to the host's browser (WebRTC). A free public matchmaking service (PeerJS) only introduces them; there's no game server to pay for.
- The host must keep the page open. Up to 4 drivers.
- On a few strict school or work networks, direct connections can be blocked. If friends can't join, try a phone hotspot or home Wi-Fi.
- The "Open games" list only appears when the game runs inside Claude. On the website, friends join with the 4-letter code.

## Updating the game
Replace `index.html` with the new version and upload it again (drag the folder onto Netlify again, or upload to GitHub again).
